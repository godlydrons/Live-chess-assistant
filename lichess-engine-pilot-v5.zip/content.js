/**
 * Lichess Engine Pilot — content.js v5
 *
 * Root causes identified from video:
 *
 * BUG 1: Orientation wrong — code uses cg-wrap.orientation-black to mean
 *   "we are black". But that class means the board is FLIPPED (black at bottom).
 *   When you play White, board is NOT flipped → no orientation-black class → "white" ✓
 *   BUT the move log showed all moves as "Black" → the FEN turn field was always "b"
 *   → ply counter was returning wrong parity (counting wrong elements).
 *   Fix: read ply from [data-ply] MAX VALUE, cross-check with WS ply.
 *
 * BUG 2: Clicks not registering on Lichess mobile — Chessground on mobile
 *   does NOT use click/mousedown at all for move input on touch devices.
 *   It uses ONLY the Pointer Events API with pointerType="mouse" (not "touch"!)
 *   and requires events fired on the exact <piece> or <square> element,
 *   not on cg-board itself. Also needs pointermove between down and up.
 *
 * Fix strategy for clicks:
 *   - Use document.elementFromPoint() to get the exact element at the square
 *   - Fire pointerdown on that element with pointerType "mouse"
 *   - Fire pointermove to dst square
 *   - Fire pointerup on dst element
 *   This mimics a mouse drag which Chessground handles reliably.
 *
 * BUG 3: WS inject timing — injecting via prepend() still races with
 *   Lichess's own scripts on page load. Fix: also try to patch existing
 *   open sockets by polling for window.__epFen set by page script.
 */
(function () {
  "use strict";

  const POLL_MS       = 600;
  const STOCKFISH_API = "https://stockfish.online/api/s/v2.php";

  const PIECE_FEN = {
    "white king":"K","white queen":"Q","white rook":"R",
    "white bishop":"B","white knight":"N","white pawn":"P",
    "black king":"k","black queen":"q","black rook":"r",
    "black bishop":"b","black knight":"n","black pawn":"p",
  };

  /* ── Config ──────────────────────────────────────────────────── */
  let cfg = { depth: 12, delay: 150, orientation: "auto", cropBox: null };
  chrome.storage.local.get(["depth","delay","orientation","cropBox"], (r) => {
    if (r.depth       != null) cfg.depth       = r.depth;
    if (r.delay       != null) cfg.delay       = r.delay;
    if (r.orientation != null) cfg.orientation = r.orientation;
    if (r.cropBox     != null) cfg.cropBox     = r.cropBox;
  });
  chrome.storage.onChanged.addListener((ch) => {
    if (ch.depth)       cfg.depth       = ch.depth.newValue;
    if (ch.delay)       cfg.delay       = ch.delay.newValue;
    if (ch.orientation) cfg.orientation = ch.orientation.newValue;
    if (ch.cropBox)     cfg.cropBox     = ch.cropBox.newValue;
    if (ch.cropDraw?.newValue) launchCropOverlay();
  });

  /* ── Inject WS sniffer into page context ────────────────────── */
  function injectPageScript() {
    const s = document.createElement("script");
    s.textContent = `
(function(){
  if(window.__epInjected) return;
  window.__epInjected = true;
  window.__epFen = null;
  window.__epPly = null;
  window.__epColor = null;
  const _WS = window.WebSocket;
  function patchWS(ws){
    ws.addEventListener("message", function(e){
      try{
        const d = JSON.parse(e.data);
        if(!d) return;
        // { t:"move", d:{ fen, ply, color? } }
        if(d.t==="move" && d.d){
          if(d.d.fen) window.__epFen = d.d.fen;
          if(d.d.ply!=null) window.__epPly = d.d.ply;
          window.dispatchEvent(new CustomEvent("__ep",{detail:{fen:d.d.fen,ply:d.d.ply}}));
        }
        // { t:"crowd", d:{ white:true/false } } — tells us which side we're on
        if(d.t==="crowd" && d.d){
          // not reliable for our color
        }
        // { t:"takebackOffer" } etc — ignore
        // Grab player color from round data embedded in page
        if(!window.__epColor){
          const m = document.cookie.match(/lila_socket_sri=([^;]+)/);
          // Try lichess object
          try{
            const li = window.lichess;
            if(li && li.sri) {
              // not directly useful
            }
          }catch(_){}
        }
      }catch(_){}
    });
  }
  window.WebSocket = function(...a){
    const ws = new _WS(...a);
    patchWS(ws);
    return ws;
  };
  Object.assign(window.WebSocket, _WS);
  // Also detect player color from the page's round data
  function detectColor(){
    try{
      // Lichess embeds JSON in a <script> tag with id or containing "lichess.round"
      const scripts = document.querySelectorAll('script');
      for(const s of scripts){
        const t = s.textContent;
        const m = t.match(/"color"\s*:\s*"(white|black)"/);
        if(m){ window.__epColor = m[1]; break; }
      }
    }catch(_){}
  }
  detectColor();
  document.addEventListener("DOMContentLoaded", detectColor);
})();
    `;
    (document.head || document.documentElement).prepend(s);
    s.remove();
  }
  injectPageScript();

  /* ── Receive WS events ───────────────────────────────────────── */
  let wsFen = null, wsPly = null;
  window.addEventListener("__ep", (e) => {
    if(e.detail.fen) wsFen = e.detail.fen;
    if(e.detail.ply != null) wsPly = e.detail.ply;
    log("WS: ply=" + wsPly + " fen=" + (wsFen||"").slice(0,30));
  });

  /* ── State ───────────────────────────────────────────────────── */
  let active=false, busy=false, lastFen="", pollTimer=null;

  chrome.storage.local.get(["active"], (r)=>{
    active=!!r.active;
    if(active) startPolling();
  });
  chrome.storage.onChanged.addListener((ch)=>{
    if(ch.active!==undefined){
      active=ch.active.newValue;
      active ? startPolling() : stopPolling();
    }
  });

  /* ── Poll ────────────────────────────────────────────────────── */
  function startPolling(){
    stopPolling();
    pollTimer=setInterval(tick, POLL_MS);
    ping("status","🟢 Watching…");
  }
  function stopPolling(){
    if(pollTimer){clearInterval(pollTimer);pollTimer=null;}
    busy=false;
    ping("status","⚫ Inactive");
  }

  async function tick(){
    if(!active||busy) return;
    const state = getBoardState();
    if(!state){ ping("status","⚠️ Board not detected"); return; }

    const turnLabel = state.isOurTurn ? "🎯 Our turn…" : "⏳ Opponent…";
    ping("status", turnLabel + " [" + state.playerColor + "/" + state.turn + "]");

    if(!state.isOurTurn) return;
    if(state.fen === lastFen) return;

    busy=true; lastFen=state.fen;
    try{
      ping("status","🔍 Engine thinking…");
      const uci = await fetchBestMove(state.fen);
      if(!uci||uci.length<4) throw new Error("No move: "+uci);
      ping("status","♟ Playing "+uci);
      log("Move: "+uci+" (we are "+state.playerColor+", turn="+state.turn+")");
      await sleep(cfg.delay);
      const moved = playMove(uci, state.orientation);
      if(moved) logMove(uci, state.turn);
    }catch(e){
      ping("status","❌ "+e.message);
      log("Error: "+e.message);
      lastFen="";
    }finally{
      busy=false;
    }
  }

  /* ══════════════════════════════════════════════════════════════
     BOARD STATE
  ══════════════════════════════════════════════════════════════ */
  function getBoardState(){
    const boardEl = document.querySelector("cg-board");
    if(!boardEl) return null;
    const rect = boardEl.getBoundingClientRect();
    if(rect.width < 50) return null;

    // ── Orientation (which side is at bottom of screen) ─────────
    const orientation = getOrientation();

    // ── Player color (which side WE are playing) ─────────────────
    const playerColor = getPlayerColor(orientation);

    // ── Current turn from WS ply or DOM ─────────────────────────
    // WS ply: AFTER move N is played, ply=N
    // ply 0 = game start (white to move)
    // ply 1 = after white's first move (black to move)
    // So: whose turn = ply%2===0 → white, ply%2===1 → black
    let turn;
    if(wsPly != null){
      turn = wsPly % 2 === 0 ? "w" : "b";
    } else {
      const domPly = getDomPly();
      turn = domPly % 2 === 0 ? "w" : "b";
    }

    // ── Is it our turn? ──────────────────────────────────────────
    const isOurTurn = (
      playerColor === "white" && turn === "w" ||
      playerColor === "black" && turn === "b"
    );

    // ── FEN ──────────────────────────────────────────────────────
    // Use WS FEN if fresh (it already has correct turn embedded)
    let fen;
    if(wsFen){
      fen = wsFen; // already correct turn from server
    } else {
      const scraped = scrapeFen(boardEl, rect, orientation);
      if(!scraped) return null;
      fen = setFenTurn(scraped, turn);
    }

    return { fen, isOurTurn, orientation, playerColor, turn, boardEl, rect };
  }

  /* ── Orientation: which side is visually at the bottom ─────── */
  function getOrientation(){
    if(cfg.orientation !== "auto") return cfg.orientation;
    const wrap = document.querySelector("cg-wrap,.cg-wrap");
    // orientation-black = board is flipped = black is at bottom
    if(wrap?.classList.contains("orientation-black")) return "black";
    return "white";
  }

  /* ── Player color: which color WE are playing ───────────────── */
  function getPlayerColor(orientation){
    // Method 1: read from injected page script color detection
    try{
      const c = unsafeWindow?.__epColor || window.__epColor;
      if(c === "white" || c === "black"){ log("Color from script: "+c); return c; }
    }catch(_){}

    // Method 2: read from Lichess page JSON embedded in DOM
    try{
      const pre = document.querySelector("#page-data, script[type='application/json']");
      if(pre){
        const d = JSON.parse(pre.textContent||pre.innerText);
        if(d?.player?.color) return d.player.color;
      }
    }catch(_){}

    // Method 3: Look for color in script tags
    try{
      for(const s of document.querySelectorAll("script:not([src])")){
        const m = s.textContent.match(/"color"\s*:\s*"(white|black)"/);
        if(m){ log("Color from script tag: "+m[1]); return m[1]; }
      }
    }catch(_){}

    // Method 4: Check if we have a "Your turn" indicator on bottom
    // Lichess puts the active player's clock at the bottom
    // When it's our turn, bottom clock is highlighted/running
    const bottomRunning = document.querySelector(
      ".rclock-bottom.running, .rclock-bottom .time.running"
    );
    const topRunning = document.querySelector(
      ".rclock-top.running, .rclock-top .time.running"
    );
    // If bottom clock is running and it's currently our turn,
    // we can infer from orientation
    // Actually orientation == playerColor when board shows our side at bottom
    // (Lichess always puts your pieces at the bottom)
    log("Color fallback to orientation: "+orientation);
    return orientation;
  }

  /* ── Ply from DOM ───────────────────────────────────────────── */
  function getDomPly(){
    // [data-ply] holds actual ply number as attribute — get max value
    const els = document.querySelectorAll("[data-ply]");
    if(els.length){
      let max=0;
      for(const el of els){
        const v=parseInt(el.getAttribute("data-ply"));
        if(!isNaN(v)&&v>max) max=v;
      }
      if(max>0) return max;
    }
    // Fallback: count move elements
    for(const sel of ["l4x m2","rm6 m2","move","kwdb",".tview2 move"]){
      const n=document.querySelectorAll(sel).length;
      if(n>0) return n;
    }
    return 0;
  }

  /* ── FEN from piece DOM ─────────────────────────────────────── */
  function scrapeFen(boardEl, rect, orientation){
    const pieces = boardEl.querySelectorAll("piece");
    if(!pieces.length) return null;
    const sqW = rect.width/8, sqH = rect.height/8;
    const grid = Array.from({length:8},()=>Array(8).fill(null));
    let placed=0;
    for(const p of pieces){
      const letter = PIECE_FEN[p.className.trim()];
      if(!letter) continue;
      const style = p.getAttribute("style")||"";
      const tf = style.match(/translate\(\s*([\d.]+)px,\s*([\d.]+)px\s*\)/);
      if(!tf) continue;
      const px=parseFloat(tf[1]), py=parseFloat(tf[2]);
      let col=Math.floor(px/sqW), row=Math.floor(py/sqH);
      col=Math.max(0,Math.min(7,col)); row=Math.max(0,Math.min(7,row));
      let file,rank;
      if(orientation==="white"){file=col;rank=7-row;}
      else{file=7-col;rank=row;}
      grid[7-rank][file]=letter;
      placed++;
    }
    if(placed<10) return null;
    let fenRows="";
    for(let r=0;r<8;r++){
      let empty=0;
      for(let f=0;f<8;f++){
        const pc=grid[r][f];
        if(pc){if(empty){fenRows+=empty;empty=0;}fenRows+=pc;}
        else empty++;
      }
      if(empty) fenRows+=empty;
      if(r<7) fenRows+="/";
    }
    const castling = guessCastling(grid);
    return `${fenRows} w ${castling} - 0 1`;
  }

  function guessCastling(grid){
    let c="";
    if(grid[7][4]==="K"){if(grid[7][7]==="R")c+="K";if(grid[7][0]==="R")c+="Q";}
    if(grid[0][4]==="k"){if(grid[0][7]==="r")c+="k";if(grid[0][0]==="r")c+="q";}
    return c||"-";
  }

  function setFenTurn(fen,turn){
    const p=fen.split(" "); p[1]=turn; return p.join(" ");
  }

  /* ── Engine ─────────────────────────────────────────────────── */
  async function fetchBestMove(fen){
    const url=`${STOCKFISH_API}?fen=${encodeURIComponent(fen)}&depth=${cfg.depth}`;
    const res=await fetch(url,{credentials:"omit"});
    if(!res.ok) throw new Error("HTTP "+res.status);
    const data=await res.json();
    if(!data.success) throw new Error("Engine: "+(data.error||"fail"));
    const m=(data.bestmove||"").match(/[a-h][1-8][a-h][1-8][qrbn]?/);
    return m?m[0]:null;
  }

  /* ══════════════════════════════════════════════════════════════
     MOVE EXECUTION — v5 approach
     
     Chessground on mobile/pointer devices works like this:
     - pointerdown on a piece square → selects it
     - pointerup on a destination square → moves it
     
     Key insight from video: events must be fired on the
     EXACT ELEMENT at that pixel (piece or square), not cg-board.
     Also: Chessground checks event.target internally.
     
     We use a DRAG approach:
       pointerdown on src element
       pointermove to dst coords (required for drag detection)  
       pointerup on dst element
     
     All with pointerType="mouse", which bypasses touch-action CSS.
  ══════════════════════════════════════════════════════════════ */
  function squareCenter(sq, orientation){
    const boardEl = document.querySelector("cg-board");
    const r = cfg.cropBox || boardEl.getBoundingClientRect();
    const sqW=r.width/8, sqH=r.height/8;
    const file=sq.charCodeAt(0)-97;
    const rank=parseInt(sq[1])-1;
    let col,row;
    if(orientation==="white"){col=file;row=7-rank;}
    else{col=7-file;row=rank;}
    return{x:r.left+col*sqW+sqW/2, y:r.top+row*sqH+sqH/2};
  }

  function mkPointer(type, x, y, buttons){
    return new PointerEvent(type,{
      bubbles:true, cancelable:true,
      clientX:x, clientY:y,
      screenX:x, screenY:y,
      pointerId:1,
      pointerType:"mouse",   // ← key: use mouse not touch
      isPrimary:true,
      button: buttons>0?0:-1,
      buttons: buttons,
      pressure: buttons>0?0.5:0,
    });
  }

  function playMove(uci, orientation){
    const from=uci.slice(0,2), to=uci.slice(2,4), promo=uci[4]||null;
    const src=squareCenter(from, orientation);
    const dst=squareCenter(to,   orientation);

    log(`Move ${from}→${to} src(${src.x.toFixed(0)},${src.y.toFixed(0)}) dst(${dst.x.toFixed(0)},${dst.y.toFixed(0)})`);

    // Get elements at exact coordinates
    const srcEl = document.elementFromPoint(src.x, src.y) || document.querySelector("cg-board");
    const dstEl = document.elementFromPoint(dst.x, dst.y) || document.querySelector("cg-board");
    const board = document.querySelector("cg-board");

    // Step 1: pointerdown on src piece
    srcEl.dispatchEvent(mkPointer("pointerover",  src.x, src.y, 0));
    srcEl.dispatchEvent(mkPointer("pointerenter", src.x, src.y, 0));
    srcEl.dispatchEvent(mkPointer("pointerdown",  src.x, src.y, 1));

    // Step 2: pointermove toward dst (drag detection)
    const midX=(src.x+dst.x)/2, midY=(src.y+dst.y)/2;
    board.dispatchEvent(mkPointer("pointermove", midX, midY, 1));
    board.dispatchEvent(mkPointer("pointermove", dst.x, dst.y, 1));

    // Step 3: pointerup on dst square
    dstEl.dispatchEvent(mkPointer("pointerup",   dst.x, dst.y, 0));
    dstEl.dispatchEvent(mkPointer("pointerout",  dst.x, dst.y, 0));
    dstEl.dispatchEvent(mkPointer("pointerleave",dst.x, dst.y, 0));

    // Also fire click-based approach as fallback (Chessground handles both)
    setTimeout(()=>{
      // If drag didn't work, try click-click
      const srcEl2 = document.elementFromPoint(src.x, src.y) || board;
      srcEl2.dispatchEvent(new MouseEvent("mousedown",{bubbles:true,cancelable:true,clientX:src.x,clientY:src.y,button:0,buttons:1}));
      srcEl2.dispatchEvent(new MouseEvent("mouseup",  {bubbles:true,cancelable:true,clientX:src.x,clientY:src.y,button:0,buttons:0}));
      srcEl2.dispatchEvent(new MouseEvent("click",    {bubbles:true,cancelable:true,clientX:src.x,clientY:src.y,button:0,buttons:0}));
    }, 80);

    setTimeout(()=>{
      const dstEl2 = document.elementFromPoint(dst.x, dst.y) || board;
      dstEl2.dispatchEvent(new MouseEvent("mousedown",{bubbles:true,cancelable:true,clientX:dst.x,clientY:dst.y,button:0,buttons:1}));
      dstEl2.dispatchEvent(new MouseEvent("mouseup",  {bubbles:true,cancelable:true,clientX:dst.x,clientY:dst.y,button:0,buttons:0}));
      dstEl2.dispatchEvent(new MouseEvent("click",    {bubbles:true,cancelable:true,clientX:dst.x,clientY:dst.y,button:0,buttons:0}));
      if(promo) setTimeout(()=>handlePromotion(promo),250);
    }, 160);

    return true;
  }

  function handlePromotion(p){
    const tries=[
      `.promotion-choice [data-symbol="${p.toUpperCase()}"]`,
      `.promotion-choice .${p}`,`.cg-promotion .${p}`,`square.${p}`,
    ];
    for(const s of tries){const el=document.querySelector(s);if(el){el.click();return;}}
    const fb=document.querySelector(".promotion-choice piece,.cg-promotion piece");
    if(fb) fb.click();
  }

  /* ── Crop overlay ────────────────────────────────────────────── */
  function launchCropOverlay(){
    if(document.getElementById("ep-overlay")) return;
    const ov=Object.assign(document.createElement("div"),{id:"ep-overlay"});
    Object.assign(ov.style,{position:"fixed",inset:"0",zIndex:"2147483647",cursor:"crosshair",background:"rgba(0,0,0,.45)"});
    const hint=Object.assign(document.createElement("div"),{textContent:"✏️  Drag around the chess board"});
    Object.assign(hint.style,{position:"absolute",top:"16px",left:"50%",transform:"translateX(-50%)",background:"#111",color:"#3ecf74",padding:"8px 18px",borderRadius:"8px",fontFamily:"system-ui,sans-serif",fontSize:"14px",pointerEvents:"none",whiteSpace:"nowrap"});
    const box=document.createElement("div");
    Object.assign(box.style,{position:"fixed",border:"2px solid #3ecf74",background:"rgba(62,207,116,.1)",pointerEvents:"none",display:"none",boxSizing:"border-box"});
    ov.appendChild(hint);ov.appendChild(box);document.body.appendChild(ov);
    let sx=0,sy=0,drag=false;
    const xy=e=>e.touches?{x:e.touches[0].clientX,y:e.touches[0].clientY}:{x:e.clientX,y:e.clientY};
    const down=e=>{e.preventDefault();const p=xy(e);sx=p.x;sy=p.y;drag=true;Object.assign(box.style,{display:"block",left:sx+"px",top:sy+"px",width:"0",height:"0"});};
    const move=e=>{if(!drag)return;e.preventDefault();const p=xy(e);Object.assign(box.style,{left:Math.min(p.x,sx)+"px",top:Math.min(p.y,sy)+"px",width:Math.abs(p.x-sx)+"px",height:Math.abs(p.y-sy)+"px"});};
    const up=e=>{if(!drag)return;drag=false;const r=box.getBoundingClientRect();if(r.width<40||r.height<40){ov.remove();ping("cropResult","too_small");return;}cfg.cropBox={left:r.left,top:r.top,width:r.width,height:r.height};chrome.storage.local.set({cropBox:cfg.cropBox,cropDraw:false});ping("cropResult","ok");ov.remove();};
    ov.addEventListener("mousedown",down,{passive:false});
    ov.addEventListener("touchstart",down,{passive:false});
    ov.addEventListener("mousemove",move,{passive:false});
    ov.addEventListener("touchmove",move,{passive:false});
    ov.addEventListener("mouseup",up);
    ov.addEventListener("touchend",up);
  }

  /* ── Logging ─────────────────────────────────────────────────── */
  function logMove(uci, turn){
    const now=new Date().toLocaleTimeString([],{hour:"2-digit",minute:"2-digit",second:"2-digit"});
    const side=turn==="w"?"White":"Black";
    chrome.storage.local.get(["moveLog"],r=>{
      const arr=(r.moveLog||[]).slice(-49);
      arr.push(`${now}  ${uci}  (${side})`);
      chrome.storage.local.set({moveLog:arr});
    });
  }
  function ping(k,v){chrome.storage.local.set({[k]:v});}
  function sleep(ms){return new Promise(r=>setTimeout(r,ms));}
  function log(msg){console.log("[EnginePilot] "+msg);}

})();
