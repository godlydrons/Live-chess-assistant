/* popup.js v2 */

const toggle   = document.getElementById("toggle");
const statusB  = document.getElementById("statusBar");
const depthV   = document.getElementById("depthV");
const delayV   = document.getElementById("delayV");
const oriSel   = document.getElementById("oriSel");
const cropBtn  = document.getElementById("cropBtn");
const cropClr  = document.getElementById("cropClear");
const logEl    = document.getElementById("logEl");

/* ── Load stored state ─────────────────────────────────────── */
chrome.storage.local.get(
  ["active","depth","delay","orientation","cropBox","moveLog","status"],
  (r) => {
    toggle.checked       = !!r.active;
    depthV.textContent   = r.depth       ?? 12;
    delayV.textContent   = r.delay       ?? 180;
    oriSel.value         = r.orientation ?? "auto";
    renderLog(r.moveLog  ?? []);
    setStatus(r.status   ?? (r.active ? "🟢 Watching…" : "⚫ Inactive"), !!r.active);
    setCropUI(!!r.cropBox);
  }
);

/* ── Toggle ────────────────────────────────────────────────── */
toggle.addEventListener("change", () => {
  const on = toggle.checked;
  chrome.storage.local.set({ active: on });
  if (!on) {
    chrome.storage.local.set({ moveLog: [], status: "⚫ Inactive" });
    setStatus("⚫ Inactive", false);
  }
});

/* ── Depth ─────────────────────────────────────────────────── */
document.getElementById("dD").onclick = () => adj("depth", -1, 1, 16, depthV);
document.getElementById("dU").onclick = () => adj("depth", +1, 1, 16, depthV);

/* ── Delay ─────────────────────────────────────────────────── */
document.getElementById("lD").onclick = () => adj("delay", -50, 0, 2000, delayV);
document.getElementById("lU").onclick = () => adj("delay", +50, 0, 2000, delayV);

function adj(key, delta, min, max, el) {
  const next = Math.min(max, Math.max(min, parseInt(el.textContent) + delta));
  el.textContent = next;
  chrome.storage.local.set({ [key]: next });
}

/* ── Orientation ───────────────────────────────────────────── */
oriSel.addEventListener("change", () => {
  chrome.storage.local.set({ orientation: oriSel.value });
});

/* ── Crop box ──────────────────────────────────────────────── */
cropBtn.addEventListener("click", () => {
  // Signal content script to launch the overlay, then close popup
  chrome.storage.local.set({ cropDraw: true, cropResult: null });
  window.close();   // close popup so overlay is visible
});

cropClr.addEventListener("click", () => {
  chrome.storage.local.set({ cropBox: null });
  setCropUI(false);
});

function setCropUI(hasBox) {
  if (hasBox) {
    cropBtn.textContent = "✅  Crop box active";
    cropBtn.classList.add("set");
    cropClr.style.display = "block";
  } else {
    cropBtn.textContent = "✏️  Draw board crop box";
    cropBtn.classList.remove("set");
    cropClr.style.display = "none";
  }
}

/* ── Live poll ─────────────────────────────────────────────── */
setInterval(() => {
  chrome.storage.local.get(
    ["active","status","moveLog","cropBox","cropResult"],
    (r) => {
      if (toggle.checked !== !!r.active) toggle.checked = !!r.active;
      if (r.status) setStatus(r.status, !!r.active);
      renderLog(r.moveLog ?? []);
      setCropUI(!!r.cropBox);
      // Handle crop result notification
      if (r.cropResult === "ok") {
        chrome.storage.local.set({ cropResult: null });
      }
      if (r.cropResult === "too_small") {
        chrome.storage.local.set({ cropResult: null });
        setStatus("⚠️ Box too small — try again", false);
      }
    }
  );
}, 700);

/* ── Status bar ────────────────────────────────────────────── */
function setStatus(msg, active) {
  statusB.textContent = msg;
  statusB.className   = "status-bar";
  if (!msg) return;
  if (msg.startsWith("❌") || msg.startsWith("⚠️")) statusB.classList.add("warn");
  else if (active) statusB.classList.add("live");
}

/* ── Move log ──────────────────────────────────────────────── */
function renderLog(moves) {
  if (!moves.length) {
    logEl.innerHTML = '<div class="log-entry" style="color:#2a2a2a">— no moves yet —</div>';
    return;
  }
  logEl.innerHTML = moves.slice(-6).reverse()
    .map((m, i) => `<div class="log-entry${i===0?" fresh":""}">${m}</div>`)
    .join("");
}
